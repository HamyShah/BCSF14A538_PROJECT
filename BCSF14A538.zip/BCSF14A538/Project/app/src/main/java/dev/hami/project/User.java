package dev.hami.project;

/**
 * Created by ALRAFIO on 1/25/2018.
 */
public class User {

    int id;
    String name;
    String email;
    String password;
    String gender;
    String DateOfBirth;
    String loginInstant;
    String city;
    String state;
    String country;
    String phone;
    String pub_private;
}
