package dev.hami.project;

/**
 * Created by ALRAFIO on 1/25/2018.
 */
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class OptionalValues extends AppCompatActivity implements View.OnClickListener {


    private EditText et_city;
    private EditText et_state;
    private EditText et_country;
    private EditText et_phont;
    private Spinner public_private_spinner;
    private Button SubmitButton;
    private ImageView imageButton;
    private TextView tv_op_name;
    private TextView tv_op_email;
    private Button btn_skip;
    private SQLiteDatabase dbUsers;

    String nameOfUser ;
    String emailOfUser ;
    String passwordOfUser;
    String genderOfUser;
    String dateOfUser;
    String instanceOfUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_optional_values);

        et_city = (EditText)  findViewById(R.id.et_city);
        et_country = (EditText) findViewById(R.id.et_country);
        et_state = (EditText) findViewById(R.id.et_state);
        et_phont = (EditText) findViewById(R.id.et_phone);
        public_private_spinner = (Spinner) findViewById(R.id.public_private_spinner);
        SubmitButton = (Button) findViewById(R.id.btn_submit);
        imageButton = (ImageView) findViewById(R.id.imageButton);
        tv_op_name = (TextView) findViewById(R.id.tv_optional_username);
        tv_op_email = (TextView) findViewById(R.id.tv_optional_email);
        btn_skip = (Button) findViewById(R.id.btn_skip);


        ArrayList<String> pub_priDataSource = new ArrayList<>();
        pub_priDataSource.add("Public");
        pub_priDataSource.add("Private");

        ArrayAdapter<String> genderAdapter = new ArrayAdapter<String>( this, android.R.layout.simple_spinner_item ,pub_priDataSource);
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        public_private_spinner.setAdapter(genderAdapter);

        dbUsers  = openOrCreateDatabase("messager_db", MODE_PRIVATE, null);


        nameOfUser = getIntent().getStringExtra("name");
        emailOfUser = getIntent().getStringExtra("email");
        passwordOfUser = getIntent().getStringExtra("password");
        genderOfUser = getIntent().getStringExtra("genderSp");
        dateOfUser = getIntent().getStringExtra("dateBut");
        instanceOfUser = getIntent().getStringExtra("savesIns");

        tv_op_name.setText(nameOfUser);
        tv_op_email.setText(emailOfUser);

        SubmitButton.setOnClickListener(this);
        imageButton.setOnClickListener(this);
        btn_skip.setOnClickListener(this);


    }

    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.btn_submit: {
                //String savesInstance;


                dbUsers.execSQL("Insert into User Values(NULL,?,?,?,?,?,?,?,?,?,?,?)", new String[]{nameOfUser ,emailOfUser ,passwordOfUser,genderOfUser ,dateOfUser,instanceOfUser,et_city.getText().toString().trim(),et_state.getText().toString().trim(),et_country.getText().toString().trim(),et_phont.getText().toString().trim(),public_private_spinner.getSelectedItem().toString() });
                displayDialogBox(R.string.SuccessTitle, R.string.SuccessRegistered_alert_dialog, R.string.ok);

                Intent a = new Intent(this, MainActivity.class);
                startActivity(a);
                this.finish();

                break;
            }
            case R.id.imageButton : {
                takeImageFromCamera();

                break;
            }
            case R.id.btn_skip : {
                dbUsers.execSQL("Insert into User Values(NULL,?,?,?,?,?,?,?,?,?,?,?)", new String[]{nameOfUser ,emailOfUser ,passwordOfUser,genderOfUser ,dateOfUser,instanceOfUser,"","","","","" });
                displayDialogBox(R.string.SuccessTitle, R.string.SuccessRegistered_alert_dialog, R.string.ok);


                Intent a = new Intent(this, MainActivity.class);
                startActivity(a);
                this.finish();


                break;
            }
        }
    }


    private void takeImageFromCamera() {
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (i.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(i, 100);
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK) {
            saveImageToStorage(data);
            imageButton.setImageBitmap(takeImageFromStorage());
        }

    }

    private void saveImageToStorage(Intent data) {
//        File imageFile = new File(Environment.getExternalStoragePublicDirectory(
//                Environment.DIRECTORY_PICTURES), "my-photo.png");

        File imageFile = new File(this.getExternalFilesDir(
                Environment.DIRECTORY_PICTURES), "my-photo.png");

        //Toast.makeText(this, Environment.DIRECTORY_PICTURES.toString(), Toast.LENGTH_SHORT).show();
        if (!imageFile.exists()) {
            try {

                if (!imageFile.createNewFile()) {
                    Toast.makeText(this, "Failed to create an image file..", Toast.LENGTH_SHORT).show();
                }
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Exception..", Toast.LENGTH_SHORT).show();
            }
        }

        try {
            FileOutputStream fos = new FileOutputStream(imageFile);
            Bundle extras = data.getExtras();
            Bitmap imageBitman = (Bitmap) extras.get("data");
            imageBitman.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private Bitmap takeImageFromStorage() {
//        File imageFile = new File(Environment.getExternalStoragePublicDirectory(
//                Environment.DIRECTORY_PICTURES), "my-photo.png");

        File imageFile = new File(this.getExternalFilesDir(
                Environment.DIRECTORY_PICTURES), "my-photo.png");

        if (!imageFile.exists()) {
            return null;
        }

        Bitmap imgBitmap = BitmapFactory.decodeFile(imageFile.getAbsolutePath());

        return imgBitmap;
    }


    void displayDialogBox(int title , int message , int ok )
    {
        AlertDialog.Builder simple = new AlertDialog.Builder(this);
        simple.setTitle(title);
        simple.setMessage(message);
        simple.setPositiveButton(ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        simple.setCancelable(false);
        simple.create();
        simple.show();
    }
}
