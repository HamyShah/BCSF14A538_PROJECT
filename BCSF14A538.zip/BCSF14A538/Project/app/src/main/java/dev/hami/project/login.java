package dev.hami.project;

/**
 * Created by ALRAFIO on 1/25/2018.
 */


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class login extends AppCompatActivity implements View.OnClickListener {

    private EditText emailTxt;
    private EditText passwordTxt;
    private Button loginBtn;
    private Button registerBtn;

    private SharedPreferences spUsers;
    private SQLiteDatabase dbUsers;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailTxt = (EditText) findViewById(R.id.txtEmail);
        passwordTxt = (EditText) findViewById(R.id.txtPassword);
        loginBtn = (Button) findViewById(R.id.butLogin);
        registerBtn = (Button) findViewById(R.id.butRegister);

        spUsers = getSharedPreferences("sp_Users", MODE_PRIVATE);
        dbUsers  = openOrCreateDatabase("messager_db", MODE_PRIVATE, null);

        dbUsers.execSQL("CREATE TABLE IF NOT EXISTS User" +
                "(uID INTEGER PRIMARY KEY AUTOINCREMENT, uName TEXT, uEmail TEXT unique, uPassword TEXT, uGender TEXT, uDob TEXT, uLoginInstant TEXT, uCity TEXT, uState TEXT, uCountry TEXT, uPhone TEXT, uPublic TEXT);");

        //emailTxt.setText(spUsers.getString(getResources().getString(R.string.Email), "def"));
        //passwordTxt.setText(spUsers.getString(getResources().getString(R.string.Password), "def"));
        if(!emailTxt.getText().toString().trim().equals("def"))
        {
            Cursor c = dbUsers.rawQuery("Select * from User where uEmail =? and uPassword =?",new String[]{String.valueOf(emailTxt.getText()),String.valueOf(passwordTxt.getText())});
            c.moveToFirst();
            if(c.getCount() == 1)
            {
                User  user = new User();
                user.id = c.getInt(0);
                user.name = c.getString(1);
                user.email = c.getString(2);
                user.password = c.getString(3);
                user.gender = c.getString(4);
                user.DateOfBirth = c.getString(5);
                user.loginInstant = c.getString(6);
                user.city = c.getString(7);
                user.state = c.getString(8);
                user.country = c.getString(9);
                user.phone = c.getString(10);
                user.pub_private = c.getString(11);

                if(user.loginInstant.equals("Yes"))
                {
                    Intent a = new Intent(this, HomePage.class);
                    startActivity(a);
                    this.finish();
                }
            }
        }
        else
        {
            emailTxt.setText("");
            passwordTxt.setText("");
            emailTxt.setHint("Email");
            passwordTxt.setHint("Password");
        }

        loginBtn.setOnClickListener(this);
        registerBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String regex = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(emailTxt.getText().toString().trim());

        Cursor c = dbUsers.rawQuery("Select * from User where uEmail =?", new String[]{String.valueOf(emailTxt.getText().toString().trim())});
        c.moveToFirst();

        switch (v.getId()){
            case R.id.butLogin : {
                System.out.println("EMail is :" + emailTxt.getText().toString().trim());
                System.out.println("Password is :" + passwordTxt.getText().toString().trim());
                if(emailTxt.getText().toString().trim().equals(""))
                {
                    displayDialogBox(R.string.ErrorTitle, R.string.NoEmail_alert_dialog, R.string.ok);
                }

                else if(!matcher.matches())
                {
                    displayDialogBox(R.string.ErrorTitle, R.string.ValidEmail_alert_dialog, R.string.ok);

                }
                else if(passwordTxt.getText().toString().trim().equals(""))
                {
                    displayDialogBox(R.string.ErrorTitle, R.string.NoaPassword_alert_dialog, R.string.ok);
                }

                else if(passwordTxt.getText().toString().trim().length() < 6 ||  passwordTxt.getText().toString().trim().length() > 12 ) {
                    displayDialogBox(R.string.ErrorTitle, R.string.ValidPassword_alert_dialog, R.string.ok);
                }
                else if(c.getCount() != 1)
                {
                    displayDialogBox(R.string.ErrorTitle, R.string.NoUser_alert_dialog, R.string.ok);
                }
                else if(c.getCount() == 1 && !c.getString(3).equals(passwordTxt.getText().toString().trim()))
                {
                    displayDialogBox(R.string.ErrorTitle, R.string.NoPasswordMatch_alert_dialog, R.string.ok);
                }
                else if(c.getCount() == 1 && c.getString(3).equals(passwordTxt.getText().toString().trim()))
                {
                    displayDialogBox(R.string.SuccessTitle, R.string.Success_alert_dialog, R.string.ok);

                    User  user = new User();
                    user.id = c.getInt(0);
                    user.name = c.getString(1);
                    user.email = c.getString(2);
                    user.password = c.getString(3);
                    user.gender = c.getString(4);
                    user.DateOfBirth = c.getString(5);
                    user.loginInstant = c.getString(6);
                    user.city = c.getString(7);
                    user.state = c.getString(8);
                    user.country = c.getString(9);
                    user.phone = c.getString(10);
                    user.pub_private = c.getString(11);

                    SharedPreferences.Editor editor = spUsers.edit();
                    editor.putString(getResources().getString(R.string.Password), user.password );
                    editor.putString(getResources().getString(R.string.Email),user.email);
                    editor.putString(getResources().getString(R.string.Name),user.name);

                    editor.commit();

                    Intent a = new Intent(this, HomePage.class);
                    startActivity(a);
                    this.finish();
                }

                break;
            }
            case R.id.butRegister : {
                Intent a = new Intent(this, Register.class);
                startActivity(a);

                break;
            }


        }
    }
    void displayDialogBox(int title , int message , int ok )
    {
        AlertDialog.Builder simple = new AlertDialog.Builder(this);
        simple.setTitle(title);
        simple.setMessage(message);
        simple.setPositiveButton(ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        simple.setCancelable(false);
        simple.create();
        simple.show();
    }
}