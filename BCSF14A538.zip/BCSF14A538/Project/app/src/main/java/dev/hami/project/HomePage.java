package dev.hami.project;

/**
 * Created by ALRAFIO on 1/25/2018.
 */

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomePage extends AppCompatActivity implements View.OnClickListener {

    private Button logout;
    private SharedPreferences spUsers;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        logout = (Button) findViewById(R.id.butLogout);
        spUsers = getSharedPreferences("sp_Users", MODE_PRIVATE);
        logout.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.butLogout : {
                SharedPreferences.Editor editor = spUsers.edit();
                editor.putString(getResources().getString(R.string.Password), "" );
                editor.putString(getResources().getString(R.string.Email),"");
                editor.putString(getResources().getString(R.string.Name),"");
                editor.commit();
                Intent a = new Intent(this, MainActivity.class);
                startActivity(a);
                this.finish();
            }
        }

    }
}
