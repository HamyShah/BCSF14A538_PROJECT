package dev.hami.project;


import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private SharedPreferences spUsers;
    private TextView username1;
    private TextView email1;
    private Button logoutBtn;
    private SQLiteDatabase dbUsers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username1 = (TextView) findViewById(R.id.username1);
        email1 = (TextView) findViewById(R.id.email1);


        logoutBtn = (Button) findViewById(R.id.btnLogout);


        logoutBtn.setOnClickListener(this);

        spUsers = getSharedPreferences("sp_Users", MODE_PRIVATE);
        dbUsers  = openOrCreateDatabase("messager_db", MODE_PRIVATE, null);


        username1.setText(spUsers.getString(getResources().getString(R.string.Name), "def"));
        email1.setText(spUsers.getString(getResources().getString(R.string.Email), "def"));
        if(username1.getText().equals(""))
        {
            Intent a = new Intent(this, login.class);
            startActivity(a);
            this.finish();
        }


    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.btnLogout: {
                SharedPreferences.Editor editor = spUsers.edit();
                editor.putString(getResources().getString(R.string.Password), "");
                editor.putString(getResources().getString(R.string.Email), "");
                editor.putString(getResources().getString(R.string.Name), "");
                editor.commit();
                Intent a = new Intent(this,login.class);
                startActivity(a);
                this.finish();
            }
        }

    }

}
