package dev.hami.project;

/**
 * Created by ALRAFIO on 1/25/2018.
 */


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Register extends AppCompatActivity implements View.OnClickListener {

    private EditText nameTxt;
    private EditText emailTxt;
    private EditText passwordTxt;
    private Spinner genderSpinner;
    private DatePicker DobDatePicker;
    private Switch loginInstantSwitch;
    private CheckBox AgreementCheckbok;
    private Button RegisButton ;
    private Button dateButton ;

    private SQLiteDatabase dbUsers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        nameTxt = (EditText)  findViewById(R.id.nameTxt);
        emailTxt = (EditText) findViewById(R.id.txtemail);
        passwordTxt = (EditText) findViewById(R.id.txtpassword);
        genderSpinner = (Spinner) findViewById(R.id.Genderspinner);
        DobDatePicker = (DatePicker) findViewById(R.id.dp);
        loginInstantSwitch = (Switch) findViewById(R.id.swiEnableLogin);
        AgreementCheckbok = (CheckBox) findViewById(R.id.checkBoxAgree);
        RegisButton = (Button) findViewById(R.id.butRegister);
        dateButton = (Button) findViewById(R.id.butDate);

        dbUsers  = openOrCreateDatabase("messager_db", MODE_PRIVATE, null);

        ArrayList<String> genderDataSource = new ArrayList<>();
        genderDataSource.add("Male");
        genderDataSource.add("Female");

        ArrayAdapter<String> genderAdapter = new ArrayAdapter<String>( this, android.R.layout.simple_spinner_item ,genderDataSource);
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        genderSpinner.setAdapter(genderAdapter);

        AgreementCheckbok.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (RegisButton.isEnabled()) {
                    RegisButton.setEnabled(false);
                } else
                    RegisButton.setEnabled(true);
            }
        });
        RegisButton.setEnabled(false);
        RegisButton.setOnClickListener(this);
        dateButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {


        String regex = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(emailTxt.getText().toString().trim());

        Cursor c = dbUsers.rawQuery("Select * from User where uEmail =?", new String[]{String.valueOf(emailTxt.getText().toString().trim())});
        c.moveToFirst();

        View customView = getLayoutInflater().inflate(R.layout.datepicker_dialogbox, null);
        DobDatePicker = (DatePicker) customView.findViewById(R.id.dp);

        switch (v.getId())
        {
            case R.id.butRegister:{



                if(nameTxt.getText().toString().trim().equals(""))
                {
                    displayDialogBox(R.string.ErrorTitle, R.string.NoName_alert_dialog, R.string.ok);
                }

                else if(emailTxt.getText().toString().trim().equals(""))
                {
                    displayDialogBox(R.string.ErrorTitle, R.string.NoEmail_alert_dialog, R.string.ok);
                }

                else if(!matcher.matches())
                {
                    displayDialogBox(R.string.ErrorTitle, R.string.ValidEmail_alert_dialog, R.string.ok);
                }

                else if(c.getCount() == 1)
                {
                    displayDialogBox(R.string.ErrorTitle, R.string.EmailExist_alert_dialog, R.string.ok);
                }

                else if(passwordTxt.getText().toString().trim().equals(""))
                {
                    displayDialogBox(R.string.ErrorTitle ,R.string.NoaPassword_alert_dialog ,R.string.ok);
                }

                else if(passwordTxt.getText().toString().trim().length() < 6 ||  passwordTxt.getText().toString().trim().length() > 12 ) {
                    displayDialogBox(R.string.ErrorTitle, R.string.ValidPassword_alert_dialog, R.string.ok);
                }
                else if(dateButton.getText().toString().equals("Select Date")) {
                    displayDialogBox(R.string.ErrorTitle, R.string.NoDate_alert_dialog, R.string.ok);
                }
                else{
                    String savesInstance;
                    if(loginInstantSwitch.isChecked())
                    {
                        System.out.println("Yes");
                        savesInstance = "Yes";
                    }
                    else {
                        System.out.println("No");
                        savesInstance = "No";
                    }

                    Intent a = new Intent(this, OptionalValues.class);
                    a.putExtra("name" , nameTxt.getText().toString().trim());
                    a.putExtra("email", emailTxt.getText().toString().trim());
                    a.putExtra("password", passwordTxt.getText().toString().trim());
                    a.putExtra("genderSp", genderSpinner.getSelectedItem().toString());
                    a.putExtra("dateBut", dateButton.getText().toString().trim());
                    a.putExtra("savesIns", savesInstance);


                    startActivity(a);
                    this.finish();
                }

                break;
            }
            case R.id.butDate:{
                AlertDialog.Builder custom = new AlertDialog.Builder(this);
                custom.setTitle(R.string.DatePickerDialog);
                custom.setView(customView);
                custom.setNeutralButton(R.string.cancle, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                custom.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getBaseContext(), "updated", Toast.LENGTH_SHORT).show();
                        System.out.print(DobDatePicker.getDayOfMonth());
                        String date = new StringBuilder().append(DobDatePicker.getDayOfMonth()).append("/").append(DobDatePicker.getMonth()+1).append("/").append(DobDatePicker.getYear()).toString();
                        dateButton.setText(date);
                    }
                });
                custom.setCancelable(false);
                custom.create();
                custom.show();
            }
        }
    }
    void displayDialogBox(int title , int message , int ok )
    {
        AlertDialog.Builder simple = new AlertDialog.Builder(this);
        simple.setTitle(title);
        simple.setMessage(message);
        simple.setPositiveButton(ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        simple.setCancelable(false);
        simple.create();
        simple.show();
    }
}